<?php 
 namespace App\Controller\Admin;

use App\Controller\AuthController;
use App\Controller\BaseController;
use App\Models\ClothesDonation;
use App\Models\FoodDonation;
use App\Models\OtherDonation;
use App\Models\Payment;
use App\Models\ShoesDonation;

class AdminDashboard extends BaseController 
 { 

    public function __construct()
    {
        if(!AuthController::isLoggedIn())
        {
            return redirect();
        }
    }
    public function index()
    {
        $context = [
            'title' => "DASHBOARD",
            'user' => session('user')
        ];


        return render('admin.index', $context);
    }

    public function donations($cat)
    {
        $cat = strtolower($cat);
        switch($cat)
        {
            case 'food': 
                $collection = FoodDonation::join('users', 'food_donations.email', 'users.email')
                ->orderBy('donated_at', 'DESC');
                break;
            case 'shoes': 
                $collection = ShoesDonation::join('users', 'shoes_donations.email', 'users.email')
                ->orderBy('donated_at', 'DESC');
                break;

            case 'funds': 
                $collection = Payment::join('users', 'payments.email', 'users.email')
                    ->orderBy('donated_at', 'DESC');
                break; 
            case 'others': 
                $collection = OtherDonation::join('users', 'other_donations.email', 'users.email')
                ->orderBy('donated_at', 'DESC');
                break;
            default: 
            $collection = ClothesDonation::join('users', 'clothes_donations.email', 'users.email')
            ->orderBy('donated_at', 'DESC');
        }

        $context = [
            'title' => 'Donated Items',
            'cat' => $cat,
            'collection' => $collection->get(),
            'user' => !empty(session('user')) ? session('user') : array_to_object(array())
        ];

        return render('admin.donations.listing', $context);
    }

    public function donationCharts()
    {
        $context = [
            'title' => "DASHBOARD | DONATION CHARTS",
            'user' => !empty(session('user')) ? session('user') : array_to_object(array())
        ];

        return render('admin.donations.charts', $context);
    }

    public function donationsReport()
    {
        return render('admin.donations.report', []);  
    }
 }