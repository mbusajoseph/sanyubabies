<?php
namespace App\Controller;

use System\Controller\Controller;
use System\Template\Template;

class BaseController extends Controller
{

}