<?php 
 namespace App\Models; 
 use System\Models\Model;

 class ClothesDonation extends Model 
 { 

 }