<?php 
 namespace App\Models; 
 use System\Models\Model;

 class FoodDonation extends Model 
 { 

 }