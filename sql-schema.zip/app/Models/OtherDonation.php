<?php 
 namespace App\Models; 
 use System\Models\Model;

 class OtherDonation extends Model 
 { 

 }