<?php 
 namespace App\Models; 
 use System\Models\Model;

 class Payment extends Model 
 { 

 }