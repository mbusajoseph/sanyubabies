<?php 
 namespace App\Models; 
 use System\Models\Model;

 class User extends Model 
 { 

 }