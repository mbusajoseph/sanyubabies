<?php
namespace System\Database;
class DB extends DatabaseManager
{

    
}