<?php
namespace System\Database\Schema;

class BluePrint extends ColumnDefination
{
  
}