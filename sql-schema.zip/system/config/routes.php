<?php
include_once $_SERVER['DOCUMENT_ROOT']."/app/Config/routes.php";
